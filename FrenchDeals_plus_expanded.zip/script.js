
async function loadProducts(){
  const res = await fetch('products.json');
  const products = await res.json();
  const grid = document.getElementById('products-grid');
  if(grid){
    products.forEach(p => {
      const card = document.createElement('article');
      card.className = 'card';
      card.innerHTML = `
        <img src="${p.image}" alt="${p.title}">
        <h3>${p.title}</h3>
        <p>${p.desc}</p>
        <div style="display:flex;align-items:center;justify-content:space-between;">
          <div><span class="price">${p.price.toFixed(2)} ${p.currency}</span><br><small style="color:#666">${p.supplier}</small></div>
          <div>
            <a class="btn" href="product.html?id=${encodeURIComponent(p.id)}">Voir</a>
            <button class="btn supplier-btn" data-link="${encodeURIComponent(p.affiliate_link)}" style="background:transparent;color:#111;border:1px solid #eee;margin-left:8px;">Fournisseur</button>
          </div>
        </div>
      `;
      grid.appendChild(card);
    });
    document.querySelectorAll('.supplier-btn').forEach(btn=>{
      btn.addEventListener('click', e=>{
        const link = decodeURIComponent(btn.getAttribute('data-link'));
        if(link && link !== 'null') window.open(link, '_blank');
        else alert('Lien fournisseur manquant. Remplacez votre lien affilié dans products.json');
      });
    });
  }
  const container = document.getElementById('product-container');
  if(container){
    const params = new URLSearchParams(window.location.search);
    const id = params.get('id');
    const p = products.find(x=>x.id===id) || products[0];
    container.innerHTML = `
      <div class="product-hero">
        <img src="${p.image}" alt="${p.title}">
        <div class="product-info">
          <h1>${p.title}</h1>
          <p style="color:#555">${p.desc}</p>
          <p class="price">${p.price.toFixed(2)} ${p.currency}</p>
          <div class="order-cta">
            <h3>Commander</h3>
            <p class="note">Vous serez redirigé(e) vers le site du fournisseur pour finaliser le paiement.</p>
            <p style="margin-top:10px;"><a id="buyBtn" class="btn" href="${p.affiliate_link}" target="_blank" rel="noopener">Commander maintenant</a></p>
            <p class="note">Si le lien ne marche pas, retournez à l'accueil ou contactez le support.</p>
          </div>
        </div>
      </div>
    `;
    const buy = document.getElementById('buyBtn');
    if(buy) buy.href = p.affiliate_link || '#';
  }
}

document.addEventListener('DOMContentLoaded', loadProducts);
